CipraSync
=========

This is an implementation of an unidirectional synchronization app.

Requirements
------------

    * Zope 3 interface and component packages 
      -- http://www.zope.org/DevHome/Wikis/DevSite/Projects/ComponentArchitecture/FrontPage
    
    * ElementTree
      -- http://effbot.org/zone/element-index.htm

    * Jason Orendorff's path module
      -- http://www.jorendorff.com/articles/python/path/path.py

Running tests
-------------

Before running the tests, you must modify 'zope.pythonpath' and
'zope.conf' settings in CipraSync/tests/input/writer.ini and the
'CIPRASYNC' variable in CipraSync/tests/input/zope.conf.
