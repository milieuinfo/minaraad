from zope import interface

from CipraSync.interfaces import IPathResolver

SITEROOT = '/plone'
SYNC_PATH = SITEROOT + '/synchronized'
VOCABULARY_PATH = SITEROOT + '/portal_vocabularies'


class CipraResolver:
    """Resolver for all cipra types.

    Given a record, the resolver calculates the path that the object
    should live in.

    >>> resolve = CipraResolver().resolve

    >>> resolve({'id': 'foobar', 'type': 'spam'})
    '/plone/synchronized/spam/foobar'

    >>> resolve({'vocabpath': ['foo-vocab/01', '02', '03'], 'language': 'de'})
    '/plone/portal_vocabularies/foo-vocab/01_de/02_de/03_de'
    
    >>> resolve({'id': 'foobar'})
    Traceback (most recent call last):
    ...
    KeyError: 'type'
    """
    interface.implements(IPathResolver)

    def resolve(self, record):
        if record.has_key('vocabpath'):
            # vocabularyterms have to go to portal_vocabularies
            sep = "_%s/" % record['language']
            langPath = sep.join(record['vocabpath'])
            path = "%s/%s_%s" % (VOCABULARY_PATH, langPath,
                                 record['language'])
        else:
            # use type and id for all other content types
            path = "%s/%s/%s" % (SYNC_PATH, record['type'], record['id'])
        return path.replace('//', '/')
