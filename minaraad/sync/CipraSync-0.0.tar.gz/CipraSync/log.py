import logging
import sys

_logger = None

def getSimpleLogger(name='CipraSync.logger',
                    fmt='%(name)-12s: %(levelname)-8s %(message)s'):
    """A default logger."""
    global _logger

    if _logger is None:
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        console =  logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(fmt)
        console.setFormatter(formatter)
        logger.addHandler(console)
        _logger = logger

    return _logger
