from zope import interface
from zope import component


from CipraSync.interfaces import (IPathResolver, IDeferredValue,
                                  IReference, IWriteHandler,
                                  ICipraWriter,
                                  ILanguageIndependentValue,
                                  IOrderableReference)

# XXX Write tests

class BaseHandler(object):
    interface.implements(IWriteHandler)    
    component.adapts(ICipraWriter)
    
    def __init__(self, context):
        self.context = context
        self.logger = self.context.logger
        self.resolver = self.context.resolver
        self.stopOnError = self.context.stopOnError

    # These two methods are defined for convenience and for fulfilling
    # the IWriteHandler contract:
    def write(self, record):
        pass

    def cleanUp(self):
        pass

class BasicHandler(BaseHandler):
    """Handles the creation of objects and setting non deferred
    values.

    This is usually the first handler for records representing content
    objects."""

    def __init__(self, context):
        super(BasicHandler, self).__init__(context)
        self.history = {}

    def write(self, record):
        path = self.resolver.resolve(record)
        parent = self._getContainer(path)
        obj = self._getOrCreateObject(record['type'], parent, path)

        values = {}
        for key, value in record.items():
            if (not IDeferredValue.providedBy(value) and
                key not in ('id', 'type', 'vocabpath')):
                values[key] = value
        
        try:
            obj.update(**values) # calls reindexObject
        except UnicodeDecodeError:
            self.logger.error(
                "UnicodeError while updating values for %r with id %r.  "
                "Make sure you have used a text-transform for all fields "
                "containing non ascii characters" % (obj.portal_type, obj.id))
            if self.stopOnError:
                raise
            else:
                return
            

        if parent not in self.history:
            self.history[parent] = set()
        self.history[parent].add(obj.getId())
        
        self.logger.debug(
            "%s: Updated attributes: %s." %
            ('/'.join(obj.getPhysicalPath()), ', '.join(values.keys())))

        get_transaction().commit(1)

    def cleanUp(self):
        for parent, synced_ids in self.history.items():
            item_ids = set(parent.contentIds())
            waste = tuple(item_ids - synced_ids)
            parent.manage_delObjects(list(waste))
            self.logger.debug(
                "%s: Deleted waste: %s." %
                ('/'.join(parent.getPhysicalPath()), ', '.join(waste)))

    def _getContainer(self, path):
        """Returns the container object for an the object that will
        live in ``path``."""
        # TODO: Policy for creating containers if they don't exist
        p = path.split('/')[:-1]
        pos = self.context.app
        for index, el in enumerate(p):
            try:
                pos = pos.restrictedTraverse(el)
            except KeyError:
                self.logger.critical(
                    "%s: Failed to get to %r." %
                    (path, '/'.join(p[:index+1])))
                raise
        return pos

    def _getOrCreateObject(self, type, container, path):
        """Retrieves or creates object at path and returns it."""
        from Acquisition import aq_base
        name = path.split('/')[-1]
        unwrappedContainer = aq_base(container)
        obj = getattr(unwrappedContainer, name, None)
        if obj is None:
            name = container.invokeFactory(type, name)
            self.logger.debug("%s: Created %s." % (path, type))
        else:
            self.logger.debug("%s: %s already existed." % (path, type))
            
        return getattr(container, name)


class ReferenceHandler(BaseHandler):
    """A handler for Reference values, which are both IReference and
    IDeferredValue in our case."""

    def write(self, record):

        for key, value in record.items():
            if IReference.providedBy(value):
                self._addReference(value)

    def _addReference(self, ref):
        # TODO: Policy for existing references: Delete or add?  Right
        # now we add.
        # TODO: Take into account multiple reference values, which
        # should implement IReference, too.

        
        #the source object should always exist, right?
        source = self.context.app.restrictedTraverse(ref.source)
        
        #but we need to check if the referred object is available
        try:
            target = self.context.app.restrictedTraverse(ref.target)
        except AttributeError:
            self.logger.error("%s: Could not add reference to %r. The "
                              "object does not exist!" %
                              (ref.source, ref.target))
            if self.stopOnError:
                raise
            else:
                return

        atRef = source.addReference(target, ref.referenceType)
        
        # if this reference also implements IOrderaableReference
        # we have to set the order attribute
        if IOrderableReference.providedBy(ref):
            atRef.order = ref.order

        self.logger.debug("%s: Successfully added reference to %r." %
                          (ref.source, ref.target))


class LinguaploneHandler(BaseHandler):
    """A Handler for LinguaPlone enabled content
    
    This handler assumes content of the same type
    to be stored in the same folder.
    LinguaploneHandler sets translation references
    and language-independent attributes only on the
    canonical object.
    """
    
    def __init__(self, context):
        BaseHandler.__init__(self, context)
        
        #id of the current canonical object
        self._id=''
        #type of the current canonical object
        self._type=''
    
    def write(self, record):
        # first set the reference to the canonical object: 
        path = self.resolver.resolve(record)
        obj = self.context.app.restrictedTraverse(path)

        
        if self._isNewTranslationFamily(record):
            #this record represents our new current canonical objec
            self._canonical = obj
            
            #langInd attributes are set *only* on the canonical
            self._setLangIndAttributes(record)                                    
        else:
            #this record represens a new translation for our
            #current canonical          
            obj.addTranslationReference(self._canonical)
            
        get_transaction().commit(1)
        

    def _setLangIndAttributes(self, record):
        """sets langInd attributes on self._canonical
        """
        plainAttributes = {}
        for key, wrapper in record.items():
            if ILanguageIndependentValue.providedBy(wrapper):
                #XXX filter references and other specific values
                plainAttributes[key] = wrapper.value
        self._canonical.update(**plainAttributes)

        
    def _isNewTranslationFamily(self, record):
        """records of same type having the same
        id belong to the same translationfamily
        """

        if self._type != record['type'] or self._isNewId(record['id']):
            self._id = '_'.join(record['id'].split('_')[:-1])
            self._type = record['type']
            return True
        else:
            # type and id are the same
            return False
    
    
    def _isNewId(self, id):
        """compares the id passed with self._id
        without taking the language into account
        
        _isNewId('1_sl') will return false
        for self._id == '1_de'
        """
        id = '_'.join(id.split('_')[:-1])
        return self._id != id

class TreeVocabLinguaploneHandler(LinguaploneHandler):
    """A handler for Linguaplone enabled TreeVocabularies.
    
    In contrast to ``LinguaploneHandler`` this handler
    can deal with hierarchical structures.
    For example 'foovocab/01_de/02_de_14_de' and
    'foovocab/01_en/02_en_14_en' are recognized to be
    in the same translationfamily.    
    
    As LinguaploneHandler it sets translation references
    and language-independent attributes only on the
    canonical object.
    """
    
    def __init__(self, context):
        LinguaploneHandler.__init__(self, context)
        self._vocabpath = []
        
    def _isNewTranslationFamily(self, record):
        if record['vocabpath'] != self._vocabpath:
            self._vocabpath = record['vocabpath']
            return True
        else:
            return False
