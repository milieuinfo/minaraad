from zope import interface

from ConfigParser import ConfigParser
import logging

from CipraSync.interfaces import IDeferredValue, IReference
import CipraSync.log

class Reference:
    """
    """
    interface.implements(IDeferredValue, IReference)

    def __init__(self, source=None, target=None, referenceType=None):
        self.source = source
        self.target = target
        self.referenceType = referenceType


def readConfiguration(filename):
    cfg = {}
    parser = ConfigParser()
    parser.read(filename)

    for section in parser.sections():
        for key, value in parser.items(section):
            cfg["%s.%s" % (section, key)] = value

    for key, value in parser.defaults():
        cfg['DEFAULT.%s' % key] = value

    return cfg

def getLogger(name=None):
    """Returns a logger.

      o ``name`` -- A logger name.  If none is given, I will return a
        simple default logger.
    """
    if name is None:
        logger = CipraSync.log.getSimpleLogger()
    else:
        logger = logging.getLogger(name)

    return logger

def createDottedIdFromTuple(data):
    """Given a tuple, this will create an ID according to the CSV
    files for the cipra project.

    >>> createDottedIdFromTuple((1,2,3))
    '01.02.03'
    >>> createDottedIdFromTuple(('1', '2', '', '4'))
    '01.02.04'
    >>> createDottedIdFromTuple('01.02.05')
    '01.02.05'
    """

    if not isinstance(data, type('')):
        data = '.'.join(['%02d' % int(field) for field in data if field])
    return data
