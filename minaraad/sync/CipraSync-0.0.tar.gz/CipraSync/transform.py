from zope import component
from zope import interface

from path import path

from CipraSync.interfaces import (IPathResolver, ITransform,
                                  IDeferredTransform,
                                  ILanguageIndependentValue,
                                  IOrderableReference)

from CipraSync import utils

class DateTransform:
    """A transformer for dates in the cipra project.
    
    The DateTimeField accepts dates as strings.
    
    The dates provided by the CSV files have to
    be converted from 'dd.mm.YY' to 'dd.mm.YYYY'
    This Transform does not care whether
    the date is valid or not.
    
    >>> t = DateTransform()
    >>> t('29.09.2004')
    '29.09.2004'
    """
    interface.implements(ITransform)

    def __call__(self, data):        
        if not data:
            # empty strings can't be unpacked
            return None
        day, month, year = data.split('.')
        return "%s.%s.%s" % (day, month, year)


class FileTransform:
    """A transform that returns a file object for
    a filename
    
    Logs any errors (eg: if the file could not be
    found.)
    
    >>> #t = FileTransform()
    >>> #t('fileThatDoesNotExist')
    ...
    IOError: [Errno 2] No such file or directory...
    
    >>> #t('someFilename')
    <open file 'someFilename', mode 'r' at ...>
    """
    interface.implements(ITransform)
    
    def __init__(self, key, configFilename=''):
        
        # if configuration is not given, use standard reader.ini
        if not configFilename:
            configFilename = path(__file__).parent / 'etc' / 'reader.ini'
        
        cfg = utils.readConfiguration(configFilename)
        self.path = cfg[key]
        self.logger = utils.getLogger(name=cfg.get('Logging.name'))

          
        
    def __call__(self, data):
        f = None
        try:
            f = file(self.path + data)
        except IOError:
            self.logger.error("Problems setting the file %s\n"
                               % self.path + data, exc_info=1)
        return f
        
        

class TextTransform:
    """A transform for Windows 1252 string to Unicode with a custom
    mapping.

    >>> t = TextTransform()
    >>> t('\xfe\xa2 (Hatschek)')
    u'\u010c\u010d (Hatschek)'
    """
    interface.implements(ITransform)

    encoding = 'windows-1252'
    mapping = {u'\xfe': u'\u010c',
               u'\xa2': u'\u010d',
               u'\x0b': u'\n',
               }

    def __call__(self, data):
        data = unicode(data, self.encoding)

        for old, new in self.mapping.items():
            data = data.replace(old, new)

        return data



class AddressTypeTransform:
    """Transform that returns the ``portal_type`` 'CipraAddress'
    
    >>> t = AddressTypeTransform()
    >>> t(None)
    'CipraAddress'
    """
    interface.implements(ITransform)
    
    def __call__(self, data=None):
        return 'CipraAddress'

class TreeVocabularyTermTransform:
    """Transform that returns the ``portal_type`` 'TreeVocabularyTerm'
    
    >>> t = TreeVocabularyTermTransform()
    >>> t(None)
    'TreeVocabularyTerm'
    """
    interface.implements(ITransform)
    
    def __call__(self, data=None): 
        return 'TreeVocabularyTerm'
    
class LanguageTransform:
    """
    Transforms language ids used in Sprachen.txt to the 2 letter abbr.
    as it is used in plone's languagetool.
    
    >>> t = LanguageTransform()
    >>> t('1')
    'de'
    """
    interface.implements(ITransform)
    
    mapping = {
        '1': 'de',
        '2': 'en',
        '3': 'fr',
        '4': 'it',
        '5': 'sl'}
    
    def __call__(self, data): 
        return self.mapping[data]

class LanguageIndependentTransform:
    """Transform that adds the marker interface
    ``ILanguageIndependentValue``
    
    The original value will be wrapped by a
    class providing ILanguageIndependentValue.
    the original value can be accessed using
    the attribute value.    
    >>> t = LanguageIndependentTransform()
    >>> value = t('Some translated title')
    >>> value.value
    'Some translated title'
    >>> from CipraSync.interfaces import ILanguageIndependentValue
    >>> from CipraSync.interfaces import IDeferredValue
    >>> ILanguageIndependentValue.providedBy(value)
    True
    >>> IDeferredValue.providedBy(value)
    True
    """
    interface.implements(ITransform)
    
   
    class LanguageIndependentValue:
        """tiny wrapper for all languageindependent values
        """
        interface.implements(ILanguageIndependentValue)
        
        def __init__(self, value):
            self.value = value


    def __call__(self, data):
        return LanguageIndependentTransform.LanguageIndependentValue(data)
    
    
    
class TreeVocabularyPathTransform:
    """A deferred transform that computes the path
    of a hierarchical vocabulary.
             
    >>> t = TreeVocabularyPathTransform()
    >>> record = {'path' : '01.14.05.01'}    
    >>> t(None, record)
    '01/14/05/01'
    """
    interface.implements(IDeferredTransform)
    
    def __call__(self, data, record):
       return record['path'].replace('.', '/')
    
    
    
class IdTransform:
    """A simple deferred transform that creates an id composed
    of the record values for 'id' and 'language'.

    >>> t = IdTransform()
    >>> t('1234', {'language': 'en'})
    '1234_en'
    """
    interface.implements(IDeferredTransform)

    def __call__(self, data, record): 
        return '%s_%s' % (data, record['language'])

class DomainTreeVocabularyTransform:
    """A transform that parses a treevocabs path
    prefixes it with the name 'cipradomains'
    and returns it in form of a list.
    
    >>> t = DomainTreeVocabularyTransform()
    >>> t('01.14.02.05')
    ['cipradomains/01', '14', '02', '05']
    """
    interface.implements(ITransform)
    
    def __call__(self, data):
        path = data.split('.')
        path[0] = "cipradomains/%s" % path[0]
        return path

class TypeTransform:
    """A transform that maps the ids for types to portal_types
    
    >>> t = TypeTransform()
    >>> t('1')
    'CipraNews'
    """
    interface.implements(ITransform)
    
    mapping = {
        '1': 'CipraNews',
        '3': 'CipraDoc',
        '4': 'CipraPublication',
        '5': 'CipraEvent',
        '9': 'CipraImage',
        '10': 'CipraPDF'
        }
    #XXX add other types here 
    
    
    def __call__(self, data):
        return TypeTransform.mapping[data]
        
class MetaReferenceTransform:
    """A deferred transform for "metareferences" such as
    related items.
    
    A metareference is given in a separate export file, instead
    of beeing represented by an id in a specific column.
    
    >>> from zope.interface.verify import verifyClass, verifyObject
    >>> verifyClass(IDeferredTransform, MetaReferenceTransform)
    True
    
    >>> from CipraSync import configure
    >>> configure.resolver()
    
    >>> t = MetaReferenceTransform('relatesTo')
    >>> record={'sourceId': '1', 'sourceType': 'Document',
    ...         'targetId': '4_de', 'targetType': 'News'}
    
    metareferences are not defined on an attribute therefore
    data is always ``None``
    >>> ref = t(None, record)

    >>> ref
    <CipraSync.utils.Reference instance ...>
    >>> ref.source
    '/plone/synchronized/Document/1'
    >>> ref.target
    '/plone/synchronized/News/4_de'
    >>> ref.referenceType
    'relatesTo'
    
    >>> from CipraSync.interfaces import IReference, IDeferredValue
    >>> verifyObject(IReference, ref)
    True
    >>> IDeferredValue.providedBy(ref)
    True
    """
    interface.implements(IDeferredTransform)
    
    def __init__(self, referenceType):
        self.referenceType = referenceType
    
    def __call__(self, data, record):
        resolver = component.getUtility(
            IPathResolver,
            name='cipra-resolver')
        
        sourceRecord = dict(id=record['sourceId'], type=record['sourceType'])
        targetRecord = dict(id=record['targetId'], type=record['targetType'])
        
        resolve = resolver.resolve
        ref =  utils.Reference(source=resolve(sourceRecord),
                               target=resolve(targetRecord),
                               referenceType=self.referenceType)
        return ref                               
                               
relatedItemsMetaReferenceTransform = MetaReferenceTransform('cipraRelatesTo')


class OrderedMetaReferenceTransform(MetaReferenceTransform):
    """Deferred transform that returns References that
    can be ordered.
    
    Attention: Use this transform only if your records provide
    a value for the 'order' key.
    

    >>> from zope.interface.verify import verifyClass, verifyObject
    >>> verifyClass(IDeferredTransform, OrderedMetaReferenceTransform)
    True
    
    >>> from CipraSync import configure
    >>> configure.resolver()
    
    >>> t = OrderedMetaReferenceTransform('relatesTo')
    >>> record={'sourceId': '1', 'sourceType': 'Document',
    ...         'targetId': '4_de', 'targetType': 'News'}
    
    
    metareferences are not defined on an attribute therefore
    data is always ``None``
    >>> ref = t(None, record)
    Traceback (most recent call last):
    ...
    AssertionError: OrderedMetaReferenceTransform needs record['order']
    
    our record does not provide a value for 'order'
    which is needed by this transform, so let's add it
    
    >>> record['order'] = '1'
    >>> ref = t(None, record)
    
    >>> ref
    <CipraSync.utils.Reference instance ...>
    >>> ref.source
    '/plone/synchronized/Document/1'
    >>> ref.target
    '/plone/synchronized/News/4_de'
    >>> ref.referenceType
    'relatesTo'
    
    >>> from CipraSync.interfaces import (IReference,
    ...         IDeferredValue, IOrderableReference)
    >>> verifyObject(IReference, ref)
    True
    >>> verifyObject(IOrderableReference, ref)
    True
    >>> IDeferredValue.providedBy(ref)
    True
    """
    interface.implements(IDeferredTransform)
    
    def __init__(self, referenceType):
        MetaReferenceTransform.__init__(self, referenceType)

    def __call__(self, data, record):
        ref = MetaReferenceTransform.__call__(self, data, record)
        
        #records need to define an order, otherwhise
        #one should not use this transform!
        assert record.has_key('order'), "OrderedMetaReferenceTransform needs record['order']"
        ref.order = record['order']
        interface.directlyProvides(ref, IOrderableReference)
        return ref

relatedItemsMetaReferenceTransform = OrderedMetaReferenceTransform('cipraRelatesTo')

class ReferenceTransform:
    """A deferred transform that resolves source and target paths for
    references.

    >>> from zope.interface.verify import verifyClass, verifyObject
    >>> verifyClass(IDeferredTransform, ReferenceTransform)
    True

    >>> from CipraSync import configure
    >>> configure.resolver()

    >>> reference = domainReferenceTransform(    
    ...                 (1,2,3,4),
    ...                 record=dict(id='07.07.07',
    ...                             type='XXX Domain Type Name'))

    >>> reference
    <CipraSync.utils.Reference instance ...>
    >>> reference.source
    '/plone/synchronized/XXX Domain Type Name/07.07.07'
    >>> reference.target
    '/plone/synchronized/XXX Domain Type Name/01.02.03.04'

    >>> from CipraSync.interfaces import IReference, IDeferredValue
    >>> verifyObject(IReference, reference)
    True
    >>> IDeferredValue.providedBy(reference)
    True
    """
    interface.implements(IDeferredTransform)

    def __init__(self, targetType, referenceType):
        self.targetType = targetType
        self.referenceType = referenceType

    def __call__(self, data, record):
        resolver = component.getUtility(
            IPathResolver,
            name='cipra-resolver')

        sourceRecord = record
        targetRecord = dict(id = utils.createDottedIdFromTuple(data),
                            type = self.targetType)

        resolve = resolver.resolve
        return utils.Reference(source=resolve(sourceRecord),
                               target=resolve(targetRecord),
                               referenceType=self.referenceType)


domainReferenceTransform = ReferenceTransform('XXX Domain Type Name', 'domain')
regionReferenceTransform = ReferenceTransform('XXX Region Type Name', 'region')
newsAddressAuthorReferenceTransform = ReferenceTransform('CipraAddress', 'CipraNewsAddressRelation')
pdfAddressAuthorReferenceTransform = ReferenceTransform('CipraAddress', 'CipraPdfAddressRelation')
imageAddressAuthorReferenceTransform = ReferenceTransform('CipraAddress', 'cipraImageAuthorReference')
imageAddressObtainedFromReferenceTransform = ReferenceTransform('CipraAddress', 'cipraImageObtainedFromReference')
imageAddressCopyrightReferenceTransform = ReferenceTransform('CipraAddress', 'cipraImageCopyrightReference')