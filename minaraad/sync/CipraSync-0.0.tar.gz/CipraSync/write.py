from zope import component
from zope import interface

import os, sys

from path import path

from CipraSync.interfaces import (ICipraWriter, IReader,
                                  IPathResolver, IWriteHandler)

import utils

class Writer:
    """A writer for CipraSync.read.Reader.

    Reads configuration from an .ini file, see ``writer.ini``.

    Writes to ZODB.
    """
    component.adapts(IReader)
    interface.implements(ICipraWriter)

    configuration = None

    def __init__(self, reader, configuration=None):
        """Initialize with a given configuration filename."""
        self.reader = reader

        configuration = configuration or self.configuration
        if configuration is None:
            configuration = path(__file__).parent / 'etc' / 'writer.ini'
        
        self._processConfiguration(configuration)

    def write(self):
        """See IWriter.

        The actual writing is done by IWriteHandlers.  Our
        configuration contains a mapping of schema name -> list of
        handlers, which we use here.

        Every handling happens in its own step.  Handlers that are
        first in the list of registered handlers are guaranteed to be
        called before latter handlers.
        """
        self.app = self._getDatabase()
        recordHandlers = {} # maps record.category -> handlers
        nameHandlers = {} # maps handlername -> handler

        for record in self.reader:
            # The first round is special in that it collects all
            # handlerNames for the record.categories
            if not recordHandlers.has_key(record.category):
                handlers = self._lookupHandlersForRecord(record, nameHandlers)
                recordHandlers[record.category] = handlers

            # let's call the first step handlers:
            [h.write(record) for h in handlers[0]]

        # How many steps?
        steps = max([len(handlers) for handlers in recordHandlers.values()])
        for step in range(1, steps+1):
            for record in self.reader:
                try:
                    handlers = recordHandlers[record.category][step]
                except IndexError:
                    continue
                else:
                    [h.write(record) for h in handlers]

        if int(self.cfg.get('Policy.cleanup', '0')):
            for handler in nameHandlers.values():
                handler.cleanUp()

    def commit(self):
        """See IWriter."""
        get_transaction().commit()

    def _getDatabase(self):
        if hasattr(self, 'app'): # short-circuit if called twice
            return self.app
        
        try:
            import Zope2
            from Zope2.Startup.run import configure
        except ImportError:
            self.logger.critical("Error while importing Zope2. "
                                 "sys.path=%r" % sys.path)
            raise
        
        zope_conf = self.cfg['Zope2.zope.conf']
        self.logger.debug("Configuring Zope2 with %r." % zope_conf)
        configure(zope_conf)
        app = Zope2.app()
        self.app = self._loginUser(app)
        return self.app

    def _loginUser(self, app):
        try:
            from AccessControl.SecurityManagement import newSecurityManager
            from Testing.makerequest import makerequest
        except ImportError:
            self.logger.critical("Error while importing Zope2. "
                                 "sys.path=%r" % sys.path)
            raise
        
        username = self.cfg['User.name']
        uf_path = self.cfg['User.userfolder']

        uf = app.restrictedTraverse(uf_path)
        newSecurityManager(None, uf.getUserById(username).__of__(uf))
        return makerequest(app)
        
    def _processConfiguration(self, configuration):
        """Process configuration from a filename."""
        REQUIRED = ('Zope2.pythonpath', 'Zope2.zope.conf',
                    'Components.pathresolver',
                    'User.name', 'User.userfolder',)
        self.cfg = utils.readConfiguration(configuration)
        
        self.logger = utils.getLogger(name=self.cfg.get('Logging.name'))
        
        self.stopOnError = bool(int(
                                 self.cfg.get('Errorhandling.stopimportonerror', '1')))
        
        resolvername = self.cfg.get('Components.pathresolver')
        self.resolver = component.queryUtility(
            IPathResolver, self.cfg.get('Components.pathresolver'))
        
        for opt in REQUIRED:
            if self.cfg.get(opt, '') is '':
                msg = ("Required option %r not found in %s." %
                       (opt, configuration))                
                self.logger.critical(msg)
                raise KeyError(opt)

        # You may need to change this line to be the following if your
        # target is Zope-2.8.6:
        # sys.path.insert(0, self.cfg['Zope2.pythonpath'])
        
        sys.path.append(self.cfg['Zope2.pythonpath'])


    def _lookupHandlersForRecord(self, record, nameHandlers):
        """Handler names may be nested to indicate that handlers are
        executed in the same step.  In ('handler1', 'handler2',
        ('handler3', 'handler4')) , both 'handler3' and 'handler4' are
        executed in the same step.
        """
        value = []
        cfg = self.cfg.get('Handlers.%s' % record.category.lower(),
                           self.cfg.get('Handlers.__default__'))
        handlerNames = eval(cfg) 

        for names in handlerNames:
            if isinstance(names, str):
                names = (names,)

            handlersInStep = []
            for n in names:
                handler = nameHandlers.get(
                    n, component.getAdapter(self, IWriteHandler, n))
                nameHandlers[n] = handler
                handlersInStep.append(handler)

            value.append(handlersInStep)

        return value
