import unittest
from zope.testing.doctestunit import DocTestSuite
from zope.testing.doctest import ELLIPSIS

from path import path

from CipraSync.write import Writer

class TestWriter:

    def test_initialize(self):
        """Test initialization at __init__ time.

        >>> config = path(__file__).parent / 'input' / 'writer.ini'
        >>> writer = Writer(None, config)
        >>> writer._getDatabase()
        DEBUG: Configuring Zope2 with '.../zope.conf'.
        <Application at ...>
        """

    def test_write(self):
        """Write.

        An IRecord implementation:

        >>> from zope import interface
        >>> from CipraSync.interfaces import IRecord
        
        >>> class MyRecord(dict):
        ...     interface.implements(IRecord)
        ...     def __init__(self, category=None, **kwargs):
        ...         super(MyRecord, self).__init__(**kwargs)
        ...         self.category = category or ''

        (writer will need the record.category for handler-lookup. normally
         the schema name is provided in this value)
         
        A fake reader:

        >>> reader = [
        ...     MyRecord(type='Document', id='mydoc_de', title='Meine Page'),
        ...     MyRecord(type='Link', id='mylink_en', title='My Link')
        ... ]

        A resolver:

        >>> from CipraSync.interfaces import IPathResolver
        
        >>> class Resolver:
        ...     interface.implements(IPathResolver)
        ...     def resolve(self, record):
        ...         return ('/plone/%ss/%s' %
        ...                 (record['type'].lower(), record['id']))

        Register the resolver with the CA:

        >>> import zope.component
        >>> zope.component.provideUtility(Resolver(), name='cipra-resolver')

        We need to register the default write handler adapter:

        >>> import CipraSync.writehandler
        >>> zope.component.provideAdapter(
        ...     CipraSync.writehandler.BasicHandler,
        ...     name='cipra-basichandler')

        Now create a writer:

        >>> config = path(__file__).parent / 'input' / 'writer.ini'
        >>> writer = Writer(reader, config)

        Let's abuse '_getDatabase' so that we have our own pointer to
        the database:

        >>> app = writer._getDatabase()
        DEBUG: Configuring Zope2 with '.../zope.conf'.
        >>> app
        <Application at ...>

        Note that there's already a Plone site in our database:

        >>> plone = app.restrictedTraverse('plone')
        >>> plone
        <PloneSite at /plone>

        In our resolver we have earlier defined that we want our
        objects to live in folders inside the Plone site:

        >>> [Resolver().resolve(record) for record in reader]
        ['/plone/documents/mydoc_de', '/plone/links/mylink_en']

        These folders, however, don't exist yet.  So when we attempt
        to write now, we'll get a KeyError and a CRITICAL debug
        message:

        >>> try:
        ...     writer.write()
        ... except KeyError, e:
        ...     print 'KeyError:', e
        CRITICAL: /plone/documents/mydoc_de: Failed to get to '/plone/documents'.
        KeyError: 'documents'

        Right now we don't have policy for creating containers in case
        they don't exist.  So we'll just create the containers and try
        again:

        >>> plone.invokeFactory('Folder', 'documents')
        'documents'
        >>> plone.invokeFactory('Folder', 'links')
        'links'

        And boom:
        
        >>> writer.write()
        DEBUG: /plone/documents/mydoc_de: Created Document.
        DEBUG: /plone/documents/mydoc_de: Updated attributes: title.
        DEBUG: /plone/links/mylink_en: Created Link.
        DEBUG: /plone/links/mylink_en: Updated attributes: title.

        Go and check out our fresh objects:

        >>> plone.documents.mydoc_de.Title()
        'Meine Page'
        >>> plone.links.mylink_en.Title()
        'My Link'

        We can update objects the same way we did first time imports.
        In our testing environment, we'll use the same writer.  In
        real world, one would do a seperate import with a new writer.

        >>> writer.reader = [MyRecord(type='Document',
        ...                           id='mydoc_de',
        ...                           title='Meine Seite')]
        >>> writer.write()
        DEBUG: /plone/documents/mydoc_de: Document already existed.
        DEBUG: /plone/documents/mydoc_de: Updated attributes: title.

        >>> plone.documents.mydoc_de.Title()
        'Meine Seite'
        
        Let's import another document, one that references our 'Meine
        Seite' document:

        >>> from CipraSync.utils import Reference
        >>> ref = Reference(source='/plone/documents/myseconddoc_de',
        ...                 target='/plone/documents/mydoc_de',
        ...                 referenceType='relatesTo')
        >>> record = MyRecord(type='Document',
        ...                   id='myseconddoc_de',
        ...                   relatedItems=ref)
        >>> writer.reader = [record]
        >>> writer.write()
        DEBUG: /plone/documents/myseconddoc_de: Created Document.
        DEBUG: /plone/documents/myseconddoc_de: Updated attributes: .

        Wait!  The debug messages say nothing about the added
        reference.  What we forgot here was to assign the
        ReferenceHandler to this kind of record.  Until now we have
        only seen the BasicHandler in action, which we registered
        earlier.

        At this point we want to associate our own set of handlers
        with the given record.  The 'kind of' record is determined by
        its 'category' attribute.

        >>> record.category = 'myspecialschema'

        Let's write the association into our writer's config by hand:

        >>> writer.cfg['Handlers.myspecialschema'] = (
        ...     "'cipra-basichandler', 'cipra-referencehandler'")

        This says that for every record that has
        'Handlers.myspecialschema' as its name, use the two handlers
        in the given order.

        We also need the ReferenceHandler under that name:

        >>> zope.component.provideAdapter(
        ...     CipraSync.writehandler.ReferenceHandler,
        ...     name='cipra-referencehandler')

        Let's try again and see how it works now:

        >>> writer.write()
        DEBUG: /plone/documents/myseconddoc_de: Document already existed.
        DEBUG: /plone/documents/myseconddoc_de: Updated attributes: .
        DEBUG: /plone/documents/myseconddoc_de: Successfully added reference to '/plone/documents/mydoc_de'.

        Let's make sure the reference has been set:

        >>> plone.documents.myseconddoc_de.getRelatedItems()
        [<ATDocument at /plone/documents/mydoc_de>]

        Currently, we don't have a way to delete references on import.
        Adding an identical reference (source, target, and type are
        the same) twice is a no-op.

        Next, we're going to try out cleanUp.  For this we have to set
        the configuration option.  Then we'll feed the writer only one
        of the items that live in the portal, with the result that the
        other items of the same type (Document) are deleted:

        >>> writer.cfg['Policy.cleanup'] = 1
        >>> reader = [
        ...     MyRecord(type='Document', id='mydoc_de', title='Meine Seite'),
        ... ]
        >>> writer.reader = reader
        >>> writer.write()
        DEBUG: /plone/documents/mydoc_de: Document already existed.
        DEBUG: /plone/documents/mydoc_de: Updated attributes: title.
        DEBUG: /plone/documents: Deleted waste: myseconddoc_de.

        >>> plone.documents.contentIds()
        ['mydoc_de']

        Note that Links are only cleaned up if an item of that type
        was imported:

        >>> reader = [
        ...     MyRecord(type='Document', id='mynewdoc'),
        ...     MyRecord(type='Link', id='mynewlink'),
        ... ]
        >>> writer.reader = reader
        >>> writer.write()
        DEBUG: /plone/documents/mynewdoc: Created Document.
        DEBUG: /plone/documents/mynewdoc: Updated attributes: .
        DEBUG: /plone/links/mynewlink: Created Link.
        DEBUG: /plone/links/mynewlink: Updated attributes: .
        DEBUG: /plone/...: Deleted waste: ...
        DEBUG: /plone/...: Deleted waste: ...

        >>> plone.documents.contentIds()
        ['mynewdoc']
        >>> plone.links.contentIds()
        ['mynewlink']
        """

def test_suite():
    import utils
    utils.setupTestLogger()
    return DocTestSuite(optionflags=ELLIPSIS,
                        setUp=utils.copyDataFS,
                        tearDown=utils.removeDataFS)

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
