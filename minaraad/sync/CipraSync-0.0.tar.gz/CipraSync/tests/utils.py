import os
import logging
import sys
import code

from path import path


_logger = None

class PrintStream:
    def write(self, string):
        print string,

    def flush(self):
        pass
    
def setupTestLogger():
    global _logger

    if _logger is None:
        name = 'CipraSync.testlogger'
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        handler =  logging.StreamHandler(PrintStream())
        formatter = logging.Formatter('%(levelname)s: %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        _logger = logger

    return _logger
    
def copyDataFS(test):
    inputpath = path(__file__).parent / 'input'
    (inputpath / 'Data.fs.orig').copy(inputpath / 'Data.fs')

def removeDataFS(test):
    inputpath = path(__file__).parent / 'input'
    os.unlink(inputpath / 'Data.fs')

    
def interact(locals=None):
   """Emulate the interactive Python interpreter.

   locals -- passed to InteractiveInterpreter.__init__()
   
   thanks to Jens Klein aka jenzenz
   """
   
   savestdout = sys.stdout
   sys.stdout = sys.stderr
   console = code.InteractiveConsole(locals)
   console.interact("exit using Ctrl-D")
   sys.stdout = savestdout
   

    