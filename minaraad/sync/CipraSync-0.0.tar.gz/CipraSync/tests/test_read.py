# -*- coding: iso-8859-1 -*-

import unittest
from zope.testing.doctestunit import DocTestSuite
from zope.testing.doctest import ELLIPSIS

from CipraSync.read import Field, Schema, Reader

class TestSchema:

    def test_typical(self):
        """Test and document the typical use of a Schema.

        Schemas eat lines of data.  Let's prepare such a line:

        >>> data = ('myid', 'mytype', '01', '2', '', '', '29.09.2004')
        >>> line = Field.DELIMITER.join(data)
        >>> line
        'myid\\tmytype\\t01\\t2\\t\\t\\t29.09.2004'

        Use some transforms from the transforms module:

        >>> from CipraSync import transform
        >>> datetransform = transform.DateTransform()
        >>> reftransform = transform.domainReferenceTransform

        >>> idfield = Field('id')
        >>> typefield = Field('type')

        >>> reffield = Field('reference', consume=2, transforms=[reftransform])
        >>> skipfield = Field(consume=2)
        >>> datefield = Field('date', transforms=[datetransform])
        
        >>> schema = Schema('base')
        >>> schema.fields.extend([idfield, typefield,
        ...                       reffield, skipfield, datefield])

        Our reffield needs the pathresolver to be registered with the CA:

        >>> from CipraSync import configure
        >>> configure.resolver()

        Now eat this:

        >>> record = schema.eat(line)

        >>> record['id'], record['type']
        ('myid', 'mytype')

        >>> ref = record['reference']
        >>> ref.source
        '/plone/synchronized/mytype/myid'
        >>> ref.target
        '/plone/synchronized/XXX Domain Type Name/01.02'

        The unnamed field does not exist in the record:

        >>> record.has_key('')
        False

        >>> record['date']
        '29.09.2004'

        >>> len(record) == 4
        True

        Schemas can have a base.  Let's extend our schema:

        >>> schema2 = Schema('extended', base=schema)
        >>> schema2.fields.append(Field('somefield'))
        >>> line = line + Field.DELIMITER + 'somedata'
        >>> len(schema2.eat(line)) == 5
        True
        """


class TestField:

    def test_transforms(self):
        """Create Field with a number of transforms to see if they're
        categorized correctly, and then eat with these transforms.

        >>> Field('field')
        Field(name='field', consume=1, transforms=[])

        >>> from zope import interface
        >>> from CipraSync.interfaces import ITransform, IDeferredTransform

        >>> class MyBase:
        ...     def __call__(self, *data):
        ...         print 'Called %s' % self.__class__.__name__
        >>> class MyTransform(MyBase):
        ...     interface.implements(ITransform)
        >>> class MyDeferredTransform(MyBase):
        ...     interface.implements(IDeferredTransform)

        >>> transforms = MyTransform(), MyDeferredTransform()
        >>> field = Field('somefield', transforms=transforms)

        ITransforms and IDeferredTransforms can now be accessed
        through different attributes:

        >>> field.transforms
        [<...MyTransform instance ...>]
        >>> field.deferredtransforms
        [<...MyDeferredTransform instance ...>]

        Now let's eat data.  ITransforms are called here, while
        IDeferredTransforms are for when the data of the whole schema
        has been built.

        >>> field.eat(Field.DELIMITER.join(('one', 'two')))
        Called MyTransform
        (None, 'two')
        """

    def test_consume(self):
        """Check whether consume works properly within the eat method.

        >>> line = Field.DELIMITER.join(('column one', 'column two'))

        >>> Field('consume1', consume=1).eat(line)
        ('column one', 'column two')
        
        >>> Field('consume2', consume=2).eat(line)
        (['column one', 'column two'], '')
        
        >>> Field('consume3', consume=3).eat(line)
        Traceback (most recent call last):
        ...
        ParseError: Could not extract 3 columns from line for field consume3.

        Unnamed fields may consume too much:

        >>> Field(consume=4).eat(line)
        (['column one', 'column two'], '')
        """


class TestReader:

    def test_read_input(self):
        """Test with some input data.

        >>> from path import path
        >>> input_path = path(__file__).parent / 'input'

        Register transforms and resolver:

        >>> from CipraSync import configure
        >>> configure.transforms()
        >>> configure.resolver()

        Now read from schema definition and source:

        >>> reader = Reader(input_path / 'reader.ini')
        DEBUG: Read 2 schema definitions from ...input/schemadefs.xml.
        >>> reader.feed((input_path / 'News.txt',))
        >>> records = [m for m in reader]
        DEBUG: Using Schema('News', ...) for ...input/News.txt.
        >>> len(records)
        2

        >>> from zope.interface.verify import verifyObject
        >>> from CipraSync.interfaces import IRecord
        >>> verifyObject(IRecord, records[0])
        True

        >>> records[0]['language'] == 'en'
        True
        >>> records[1]['language'] == 'fr'
        True

        >>> records[0]['id']
        'evo-morales_en'

        >>> print records[0]['description']
        Evo Morales claims victory in the Bolivian ...

        >>> print records[1]['text']
        Les deux principaux candidats �taient Evo Morales, ...

        >>> reader.feed((input_path / 'SomeFileWithNoSchema.txt',))
        >>> for m in reader:
        ...     print m
        Traceback (most recent call last):
        ...
        ParseError: No schema found for file .../SomeFileWithNoSchema.txt.
        """


def test_suite():
    from utils import setupTestLogger
    setupTestLogger()
    return DocTestSuite(optionflags=ELLIPSIS)

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
