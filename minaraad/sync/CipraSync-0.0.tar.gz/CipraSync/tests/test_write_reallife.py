# -*- coding: utf-8 -*-

import unittest
from zope.testing.doctestunit import DocTestSuite
from zope.testing import doctest

from path import path

from CipraSync.write import Writer
from CipraSync.read import Reader





class TestWriteRealLife(object):
    
    def test_write(self):
        """        
        This test tries to import a subset of the 'real' cipra
        export data into a plone portal.
        
        The files are located in tests/input/data and are not
        real filemaker exports, but modified test data (less
        data, to make the test finish faster)

        To run this test you'll have to provide a INSTANCE_HOME having
        CipraWeb[1] and all it's dependencies available in Products/
        [1] https://svn.lovelysystems.com/repos/customers/cipra/CipraWeb/trunk


        register zope components:
        >>> from CipraSync import configure
        
        when configuring  transforms we get a logger message for
        each transform that that uses a logger
        >>> configure.transforms()
        >>> configure.resolver()
        >>> configure.writehandlers()
        
        >>> from path import path
        >>> input_path = path(__file__).parent / 'input'        
        
        create a reader using the configuration from CipraSync/etc/reader.ini
        >>> reader = Reader()
        DEBUG: Read ... schema definitions from .../etc/schemadefs.xml.
        
        
        feed the reader with test-data
        we have to use ``abspath()``  here because quickinstaller later
        will change the local path during product installation
        >>> #allFiles = [file.abspath() for file in (input_path / 'data').files()]
        feed reader with each file separately so we have more control
        >>> allFiles = [
        ...      input_path / 'data' / 'FMtoPlone_News.txt',
        ...      input_path / 'data' / 'FMtoPlone_Adress.txt',
        ...      input_path / 'data' / 'FMtoPlone_Fachbereiche.txt',
        ...      input_path / 'data' / 'FMtoPlone_PDFDoku.txt',
        ...      input_path / 'data' / 'FMtoPlone_Bilder.txt',
        ...      input_path / 'data' / 'FMtoPlone_SieheAuch.txt',
        ...      ]
        >>> reader.feed(allFiles)
        
        
                
        create a writer using the config from CipraSync/etc/writer.ini
        >>> writer = Writer(reader)
       
        Let's abuse '_getDatabase' so that we have our own pointer to
        the database:
        >>> app = writer._getDatabase()
        DEBUG: Configuring Zope2 with '...zope.conf'.
        
        
        Note that there's already a Plone site in our database:
            
        >>> plone = app.restrictedTraverse('plone')
        >>> plone
        <PloneSite at /plone>


        create folders that hold syncronized content
        >>> _ = plone.invokeFactory('Folder', 'synchronized')
        
        and the folders for the types
        >>> _ = plone.synchronized.invokeFactory('Folder', 'CipraNews')
        >>> newsFolder = plone.synchronized.CipraNews
        >>> _ = plone.synchronized.invokeFactory('Folder', 'CipraAddress')
        >>> addressFolder = plone.synchronized.CipraAddress
        >>> _ = plone.synchronized.invokeFactory('Folder', 'CipraPDF')
        >>> pdfFolder = plone.synchronized.CipraPDF
        >>> _ = plone.synchronized.invokeFactory('Folder', 'CipraImage')
        >>> imageFolder = plone.synchronized.CipraImage
    
        
        We have to quickinstall CipraWeb and it's dependencies
        in the portal now...
        >>> qi = plone.portal_quickinstaller
        >>> qi
        <QuickInstallerTool at /plone/portal_quickinstaller>
        >>> qi.isProductAvailable('CipraWeb')
        1
        >>> qi.installProduct('CipraWeb')
        ...
        'Installation log of CipraWeb:...'
        
                 

        

         
        The syncer expects named Vocabularies in portal_vocabularies, too!
        Similar to the 'synchronized' folder the vocabularies have to exist.
        During the installation of CipraWeb these Vocabularies have already
        been created.        
        >>> atvm = plone.portal_vocabularies        
        >>> domainsVocab = atvm.getVocabularyByName('cipradomains')
        >>> domainsVocab        
        <TreeVocabulary at /plone/portal_vocabularies/cipradomains>




        Now let's write our objects to the database!
        >>> writer.write()
        DEBUG: Using Schema('CipraNews', Schema('CipraContentMixin', None)) for ...
        DEBUG: /plone/synchronized/CipraNews/1_de: Created CipraNews.
        DEBUG: /plone/synchronized/CipraNews/1_de: Updated attributes: ...
        ...

        
        
        Vocabularies
        ~~~~~~~~~~~~
        
        check if vocabularies got created:
               
        >>> firstVocab = domainsVocab['1_de']
        >>> firstVocab
        <TreeVocabularyTerm at /plone/portal_vocabularies/cipradomains/1_de>
        >>> len(firstVocab.getTranslations())
        5
        >>> firstVocab.getTranslation('sl')
        <TreeVocabularyTerm at /plone/portal_vocabularies/cipradomains/1_sl>
        
        
        
        see if subvocabularyterms got created correctly:
        >>> lastVocab = domainsVocab.restrictedTraverse('1_sl/1_sl/2_sl')
        >>> lastVocab
        <TreeVocabularyTerm at /plone/portal_vocabularies/cipradomains/1_sl/1_sl/2_sl>
        >>> len(lastVocab.getTranslations())
        5
        
        

        Translations
        ------------
        Let's see if Linguaplone References were set the right way:
        
        
        For news/1_X there are only 4 translations (the english one is missing)
        >>> n1 = newsFolder['1_de']        
        >>> len(n1.getTranslations())
        4
        
        news/5_X is translated in 5 languages
        >>> len(newsFolder['5_en'].getTranslations())
        5
        
        Check if translations are registered the right way:
        >>> n1.getTranslation('de')
        <CipraNews at .../CipraNews/1_de>
        >>> n1.getTranslation('fr')
        <CipraNews at .../CipraNews/1_fr>
        >>> n1.getTranslation('sl')
        <CipraNews at .../CipraNews/1_sl>
        >>> n1.getTranslation('it')
        <CipraNews at .../CipraNews/1_it>
        
        There should be no english translation for news/1_X
        >>> n1.getTranslation('en') is None
        True
        
        the canonical is always the first one found in the
        export file.
        >>> newsFolder['1_it'].getCanonical()
        <CipraNews at .../CipraNews/1_de>
        
        
        
        Addresses
        ---------
                
        XXX check not accessible by anonymous users in a
        separate testcase that is located in CipraWeb

        try to obtain an adress
        >>> a6 = addressFolder['6']
        >>> a6
        <CipraAddress at .../CipraAddress/6>
        
        Check all the fields that should be mapped        
        >>> a6.getSalutation()
        'Herr'
        >>> a6.getAcademicTitle()
        'Prof. Dr.'
        >>> a6.getFirstName()
        'Karl'
        >>> a6.getLastName()
        'Ruppert'
        
        XXX additionalTitle
        
        
        >>> a6.getInstitution()
        'Universit...nchen'
        
        'Universität München'
        
        >>> a6.getDepartment()
        'Institut ... Wirtschaftsgeographie'
        
        'Institut für Wirtschaftsgeographie'
        
        XXX role
        
        XXX adresszusatz
        
        >>> a6.getStreet()
        'Ludwigstrasse 28'
        >>> a6.getZip()
        '80539'
        >>> a6.getCity()
        'M...nchen'
        
        'München'

        XXX pob, pobZip, pobCity
        
        >>> a6.getStreetPrior()
        'Ludwigstrasse 28'
        >>> a6.getZipPrior()
        '80539'
        >>> a6.getCityPrior()
        'M...nchen'
        
        'München'
        
        >>> a6.getPobPrior()
        'Ludwigstrasse 28'
        >>> a6.getPobZipPrior()
        '80539'
        >>> a6.getPobCityPrior()
        'M...nchen'

        'München'

        
        >>> a6.getCountry()
        'DE'
        
        >>> a6.getPhone()
        '+49 89 2180 2230'
        >>> a6.getFax()
        '+49 89 2180 3809'
        
        XXX phoneDirect, faxDirect, mobile
        
        >>> a6.getEmail()
        'wigeo-sekr@bwl.uni-muenchen.de'
        >>> a6.getUrl()
        'http://www.wigeo.bwl.uni-muenchen.de/'
     
      
      
      
      
      
      
        
        XXX the following lines intentionally use >> instead of >>>
        i will activate the tests step by step        

        
        
        CipraContentMixin
        ------------------

        
        check vocabulary ``domains``
        >> domain = domainsVocab.restrictedTraverse('12_de/2_de/3_de/4_de')
        >> UID = domain.getCanonical().UID()
        >> newsFolder['1_de'].getDomains()[0] == domain
        True
        
        
        News
        ----
        
        try to obtain a news object
        >>> news = newsFolder['1_de']
        
        >>> news.getPublicationDate()
        DateTime('2004/09/22')
        
        >>> news.Title()
        'Italien: Kleinwasserkraftwerke'

                            
        >>> news.Description()
        'Seit einigen Jahren gibt es in Italien, besonders im Piemont...'
        
        
        XXX daniel: how to pass this encoding issue. declare utf-8 for this doctest??
        >>> #news.getText()
        '<p>Eine Zeit lang wurden die Antr\xc3\xa4ge dem interdisziplin\xc3\xa4ren...'        
        
        
        XXX motherwebusage
        no documentation for this field available
        
        
        check reference to address object:
        >>> news = newsFolder['5_de']
        >>> news.getAuthorAddress()
        <CipraAddress at .../CipraAddress/12640>
        
        
  



        PDF
        ---
        XXX when importing pdfs the following errors should be logged:
        4_de -> pdf 'wont_be_found.pdf' not found.
        4_5 -> no pdf file specified (pdf is required)
        
        >>> pdf2 = pdfFolder['2_de']
        >>> pdf4 = pdfFolder['4_de']
        
             
        >>> pdf2.getAuthor()
        <CipraAddress at .../CipraAddress/12640>

                
        >>> pdf2.getDateCreated()
        DateTime('2000/10/31')
        
        >>> pdf2.Title()
        'Rahmenkonvention der Alpenkonvention'
        
        >>> pdf4.Description()
        'Gesch...ftsordnung f...r die Konferenz der Vertragsparteien'
        
        'Geschäftsordnung für die Konferenz der Vertragsparteien'
        
        
        >>> pdf2.getUrl()
        'http://foo.bar.baz'
        

        >>> pdf2.getFile()
        <File at /plone/synchronized/CipraPDF/2_de/file>
        >>> pdf2.getFile().filename
        'test.pdf'
        
        
        getLanguageAppendix() -> field not used atm
        
        >>> pdf2.getNrOfPages()
        10
        
        >>> pdf2.getFileSize()
        107
        
        
        
        

                
        Images
        ------
                
        >>> img1 = imageFolder['1_de']
        >>> img1
        <CipraImage at .../CipraImage/1_de>
        
        >>> img4 = imageFolder['4_de']
        >>> img6 = imageFolder['6_de']
        
           
        >>> img1.getAuthor()
        <CipraAddress at .../CipraAddress/6>
        
        >>> img1.getObtainedFrom()
        <CipraAddress at .../CipraAddress/51>
               
        >>> img1.getCopyright()
        <CipraAddress at .../CipraAddress/58>

        >>> img1.getCaptured()
        DateTime('2002/05/02')
        >>> img6.getCaptured()
        
        img1.getCaptureTime()
        '09:11:00'
        
        >>> img1.Title()
        'Neue Architektur in den Bergen'
        
        >>> img1.Description()
        'Modernes Bauen in Fuldera'
        
        >>> img1.getCaption()
        'caption'
        
        >>> img1.getOriginalNote()
        'originalNote'
        
        >>> img1.getLocation()
        'location'
        
        >>> img4.getCopyrightText()
        'Verein Nationalpark Ges...use'
        
        XXX utf-8
        'Verein Nationalpark Gesäuse'
        
        >>> img1.getImage()
        <Image at /plone/synchronized/CipraImage/1_de/image>
        >>> img1.getImage().filename
        '001_fuldera_moderne_bauten.jpg'
        
        >>> img1.getWidth()
        25
        
        >>> img1.getHeight()
        30
        
        >>> img1.getFileSize()
        9
        >>> img1.getImage().getSize()
        8547
        
        >>> img1.getResolution()
        72
        
        
        
        
        Related Items
        -------------
        
        see if the related-items relations defined in SieheAuch.txt
        were set correctly:
            
        >>> news1 = newsFolder['1_de']
        >>> news5 = newsFolder['5_de']
        >>> news6 = newsFolder['6_de']
        >>> pdf2 = pdfFolder['2_de']
        
        >>> import utils
        >>> #utils.interact( locals() )
        
      
     
        
        news with one related item:
        CipraNews/5_de -> CipraPDF/2_de
        >>> news5.getCipraRelatedItems()
        [<CipraPDF at .../CipraPDF/2_de>]
        
        
        news with two related items (multiple references)
        CipraNews/1_de -> CipraNews/5_de & CipraNews/6_de       
        is the sequence the same all the time?
        (CIPRA-202)
        does orderedreferencefield do it's job?
        >>> news1.getCipraRelatedItems()
        [<CipraNews at .../CipraNews/5_de>, <CipraNews at .../CipraNews/6_de>]
        
        
        
        Related Items are languageIndependent?
        >>> news1.getTranslation('sl').getCipraRelatedItems()
        [<CipraNews at .../CipraNews/5_de>, <CipraNews at .../CipraNews/6_de>]
        
        
        """

    
def test_suite():
    import utils
    utils.setupTestLogger()
    optionflags = doctest.REPORT_ONLY_FIRST_FAILURE | doctest.ELLIPSIS    
    return DocTestSuite(optionflags=optionflags,
                        setUp=utils.copyDataFS,
                        tearDown=utils.removeDataFS)

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
    
