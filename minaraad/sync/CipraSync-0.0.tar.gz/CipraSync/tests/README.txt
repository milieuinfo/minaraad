These are the automatic tests for CipraSync.

To run them, run ``python test_doctest.py`` from within the test
directory.

