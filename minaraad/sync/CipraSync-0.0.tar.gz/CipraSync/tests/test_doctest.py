import unittest
from zope.testing.doctestunit import DocTestSuite
from zope.testing.doctest import ELLIPSIS

MODULENAMES = (
    'CipraSync.read',
    'CipraSync.resolve',
    'CipraSync.transform',
    'CipraSync.utils',
    'CipraSync.write',
    )

def test_suite():
    suites = []
    for module in MODULENAMES:
        suites.append(DocTestSuite(module, optionflags=ELLIPSIS))

    return unittest.TestSuite(suites)

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
