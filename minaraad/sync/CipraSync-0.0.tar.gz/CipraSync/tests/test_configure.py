import unittest
from zope.testing.doctestunit import DocTestSuite
from zope.testing.doctest import ELLIPSIS

from zope import component

from CipraSync import interfaces
from CipraSync import configure

class TestConfigure:

    def test_resolver(self):
        """
        >>> configure.resolver()
        >>> component.getUtility(interfaces.IPathResolver, 'cipra-resolver')
        <CipraSync.resolve.CipraResolver instance ...>
        """

    def test_transforms(self):
        """
        >>> configure.transforms()
        >>> names = ('id', 'date', 'domainreference', 'regionreference')
        >>> names = ['cipra-transform-%s' % name for name in names]
        >>> for name in names:
        ...     component.getUtility(interfaces.ITransform, name)
        <CipraSync.transform.IdTransform instance ...>
        <CipraSync.transform.DateTransform instance ...>
        <CipraSync.transform.ReferenceTransform instance ...>
        <CipraSync.transform.ReferenceTransform instance at ...>
        """

    def test_reader(self):
        """
        >>> configure.transforms() # our reader depends on this
        >>> configure.reader() # doctest: +ELLIPSIS
        DEBUG: Read ... schema definitions from ...
        >>> component.getUtility(interfaces.IReader)
        <CipraSync.read.Reader instance ...>
        """

    def test_writer(self):
        """
        >>> configure.transforms() # our reader depends on this
        >>> configure.reader() # doctest: +ELLIPSIS
        DEBUG: Read ... schema definitions from ...
        >>> configure.writer()
        >>> reader = component.getUtility(interfaces.IReader)
        >>> interfaces.IWriter(reader)
        <CipraSync.write.Writer instance ...>
        """


def test_suite():
    from utils import setupTestLogger
    setupTestLogger()
    return DocTestSuite(optionflags=ELLIPSIS)

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')
