from path import path

from zope.testing import testrunner


defaults = [
    '--path', path(__file__).parent,
    '--tests-pattern', '^test_*',
    '-v',
    ]

testrunner.run(defaults)
