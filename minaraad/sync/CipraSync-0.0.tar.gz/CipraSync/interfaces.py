"""Interfaces for CipraSync.

$Id$
"""
__docformat__ = "reStructuredText"

from zope import interface

class IRecord(interface.Interface):
    """A dictionary that contains transient data for use between
    IReader and IWriter.

    The keys correspond to the fields of my type in the target
    database.  The values are the field's values."""

    category = interface.Attribute("The type of record.")


class IReader(interface.Interface):
    """A raw data to IRecord converter.

    IReaders implement ways to interpret a certain type of data
    source.  IReaders delegate to ITransforms for transformation of
    data.

    You can access IRecords by looping on the IReader."""

    def feed(data):
        """
        Feed data.
        
          o ``data`` -- Can be anything from a file to a database
            handle.  Whatever is being used as a source.
        """

    def __iter__():
        """Iterate over IRecords taken from some data source.

        May be called more than once."""


class IWriter(interface.Interface):
    """An Adapter for IReader.

    IWrtiers know how to put the IRecords into the target database.
    """

    def write():
        """Write the data provided by the IReader.

        May also delete and modify other objects, e.g. when it finds
        out that some object in the database is obsolete.
        """

    def commit():
        """Commit changes to target database."""


class IDeferredValue(interface.Interface):
    """A record value that needs to be set after all objects have been
    created with the normal (i.e. non-deferred) set of values."""


class IReference(interface.Interface):
    """Reference to an object for use in an IRecord."""

    source = interface.Attribute("The path of the source object.")
    target = interface.Attribute("The path of the target object.")
    referenceType = interface.Attribute("The type of the reference.")

class IOrderableReference(IReference):
    """Orderable Reference to an object for use in an IRecord."""
    order = interface.Attribute("A number this reference can be sorted on.")

class IPathResolver(interface.Interface):
    """IPathResolvers are utilities that implement policies on how
    data records and the resulting object paths are linked.

    E.g. a record with ``{'id': 'qwe', 'language': 'en'}`` could be
    mapped to ``'qwe-en'``"""

    def resolve(record):
        """Given a dictionary ``record``, I will try to return a path
        that corresponds to the object in the target database.

        If I can't, I raise ValueError."""


class ITransform(interface.Interface):
    """ITransforms are named utilities that do transformation from
    something to something else, or maybe even to the same thing."""

    def __call__(data):
        """Returns the transformed data."""


class IDeferredTransform(ITransform):
    """A transform that's executed after all non deferred transforms
    are done.  See ITransform."""

    def __call__(data, record):
        """
          o ``data`` -- The raw data that I will transform.

          o ``record`` -- An IRecord of the object that data belongs
            to.
        """

# The interfaces below this line are really conceptionally optional. ##########

class IWriteHandler(interface.Interface):
    """A named adapter for ICipraWriter objects.

    Knows how to write records to the database.

    It is guaranteed that one single instance of a handler is used for
    every record that is written.  So you can expect instance
    attributes to survive until cleanUp time.

    IWriteHandlers are responsible for logging information about what
    they do.
    """

    def write(record):
        """Write record."""

    def cleanUp():
        """May be called by the writer to request the deletion of
        unused objects in the target database.

        Note that this is only called once per handler after all
        handlers did their write on all records.
        """


class ICipraWriter(IWriter):
    """An IWriter with a ZODB handle, a logger and a resolver."""

    app = interface.Attribute("The ZODB root.")
    logger = interface.Attribute("The logger.")
    resolver = interface.Attribute("The IPathResolver in use.")


class ILanguageIndependentValue(IDeferredValue):
    """Marker interface for record values that are
    the same for all translations of the object.
    """

    value = interface.Attribute("The actual value.")
