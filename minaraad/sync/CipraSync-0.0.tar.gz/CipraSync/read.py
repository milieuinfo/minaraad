from zope import component
from zope import interface

from elementtree.ElementTree import parse
from path import path

from CipraSync.interfaces \
     import IRecord, IReader, ITransform, IDeferredTransform

import utils

class ParseError(Exception):
    pass


class Record:
    """This IRecord implementation that tries to be clever and doesn't
    do transforms until items are accessed.

    >>> schema = Schema('myschema')
    >>> schema.fields.append(Field('myfield'))
    >>> factory = lambda: Record(schema, 'junkdata')
    >>> record = factory()
    >>> record._initialized
    False

    Note that we only initialize when certain methods are called, we
    don't support all of dict's methods thereby.

    >>> record.category
    'myschema'
    >>> record._initialized
    False

    Note that currently we only support item access and ``has_key``:

    >>> record.items()
    [('myfield', 'junkdata')]
    >>> record._initialized
    True

    >>> record = factory()
    >>> record._initialized
    False
    >>> record._dict
    {}
    >>> 'myjunk' in record
    False
    >>> record._initialized
    True
    >>> record._dict
    {'myfield': 'junkdata'}
    
    >>> record = factory()
    >>> record.get('myjunk', 'nodata')
    'nodata'
    >>> record._initialized
    True
    """
    
    interface.implements(IRecord)

    def __init__(self, schema, line):
        """``schema`` is my schema, and line the line in the CSV that
        I represent."""
        self.category = schema.name

        self._schema = schema
        self._line = line

        self._dict = {}
        self._initialized = False
    
    def _doTransforms(self):
        if not self._initialized:
            self._dict.update(self._schema.eat(self._line))
            self._initialized = True

    def __getattr__(self, name):
        self._doTransforms()
        return getattr(self._dict, name)


class Schema:
    def __init__(self, name, base=None):
        self.name = name
        self.base = base

        self.files = []
        self.fields = []

        # If we have a base, insert an unnamed field that eats just as
        # much as the base eats
        if base:
            baseconsume = sum([f.consume for f in base.fields])
            self.fields.append(Field(consume=baseconsume))

    def eat(self, line):
        """Eats a line and returns a dict that corresponds to that
        line after transformations.

        All deferred transforms have taken place after this point.
        """

        if self.base:
            mapping = self.base.eat(line)
        else:
            mapping = {}

        for f in self.fields:
            value, line = f.eat(line)
            if f.name: # skip fields with no name
                mapping[f.name] = value

        # it's time for the deferredtransforms now
        for f in self.fields:
            for t in f.deferredtransforms:
                mapping[f.name] = t(mapping[f.name], mapping)

        return mapping

    def __repr__(self):
        return 'Schema(%r, %r)' % (self.name, self.base)


class Field:
    """A field that knows how to consume data from a line.

    >>> field = Field('somefield')
    >>> data = Field.DELIMITER.join(('column one', 'column two'))
    >>> value, line = field.eat(data)
    >>> value, line
    ('column one', 'column two')

    An unnamed field is for consumation of columns that we want to skip:

    >>> field = Field(consume=777)
    >>> field.eat(data)
    (['column one', 'column two'], '')
    """
    
    DELIMITER = '\t'

    def __init__(self, name='', consume=1, transforms=None):
        self.name = name
        self.consume = consume
        
        self.transforms = []
        self.deferredtransforms = []

        for transform in transforms or []:
            if IDeferredTransform.providedBy(transform):
                self.deferredtransforms.append(transform)
            else:
                self.transforms.append(transform)

    def eat(self, line):
        """I return a 2-tuple in the form (value, line) where value is
        the value of the read in data and line is the unconsumed rest
        of the data.
        """
        
        parts = line.split(self.DELIMITER)

        # check if we are asked to consume more than there is
        if self.consume > len(parts):
            if self.name == '': # which is OK for an unnamed field
                pass
            else:
                raise ParseError("Could not extract %s columns from line for "
                                 "field %s." % (self.consume, self.name))

        # the extracted data and the rest of the line
        data = parts[:self.consume]
        if len(data) == 1:
            data = data[0]
        line = self.DELIMITER.join(parts[self.consume:])

        # do transforms, deferredtransforms are done later
        for transform in self.transforms:
            data = transform(data)

        return data, line

    def __repr__(self):
        transforms = self.transforms + self.deferredtransforms
        return ('Field(name=%r, consume=%r, transforms=%r)' % 
                (self.name, self.consume, transforms))


class Reader:
    """A reader for CSV files.

    Reads configuration from an xml file.  See ``schemadefs.xml``.
    """
    interface.implements(IReader)
    
    def __init__(self, configuration=None):
        """Initialize with a given configuration filename."""
        if configuration is None:
            configuration = path(__file__).parent / 'etc' / 'reader.ini'
        
        self._processConfiguration(configuration)

    def feed(self, data):
        """Expects data to be a list of filenames.

        See IReader.
        """
        self._filenames = data
        
    def fieldFactory(self, *args, **kwargs):
        return Field(*args, **kwargs)

    def schemaFactory(self, *args, **kwargs):
        return Schema(*args, **kwargs)

    def __iter__(self):
        """See IReader."""

        def iterRecords():
            for filename in self._filenames:

                # find the a handling Schema:
                schema = None
                for fn in self._schemabyfile.keys():
                    if filename.endswith(fn):
                        schema = self._schemabyfile[fn]
                        break

                if schema is None:
                    msg = "No schema found for file %s." % filename
                    self.logger.critical(msg)
                    raise ParseError(msg)

                self.logger.debug("Using %r for %s." % (schema, filename))

                f = open(filename)
                for line in self._tokenize(f):
                    yield Record(schema, line)

            raise StopIteration

        return iterRecords()

    def _tokenize(self, f):
        """Iterate over a file's lines."""
        for line in f:
            if line.endswith('\n'):
                line = line[:-1]
            if len(line.strip()) == 0:
                continue
            yield line

        raise StopIteration
    
    def _processConfiguration(self, configuration):
        """Process configuration from filename."""
        self.cfg = utils.readConfiguration(configuration)
        self.logger = utils.getLogger(name=self.cfg.get('Logging.name'))

        filename = self.cfg['Schemas.filename']
        p = path(configuration).parent / filename
        self._readSchemas(p)

    def _readSchemas(self, filename):
        """Read schema from XML file where filename is given."""
        self._schemas = {} # schemas by name
        self._schemabyfile = {} # schema by file

        tree = parse(filename)
        defs = tree.getroot()

        # fill self._schmemas with { name: schema }
        for definition in defs:
            name = definition.get('name') or ''
            base = definition.get('base')
            if base:
                base = self._schemas[base]

            Schema = self.schemaFactory
            schema = self._schemas[name] = Schema(name=name, base=base)
            
            for f in definition.findall('file'):
                schema.files.append(f.get('name'))
            
            for f in definition.findall('field'):
                name = f.get('name')
                consume = int(f.get('consume') or 1)

                tnames = f.get('transform')
                tnames = tnames and tnames.split() or []
                transforms = [component.getUtility(ITransform, name=tname)
                              for tname in tnames]

                Field = self.fieldFactory
                field = Field(name, consume=consume, transforms=transforms)
                schema.fields.append(field)

        # fill self._schemabyfile with { filename: schema }
        for schema in self._schemas.values():
            for f in schema.files:
                self._schemabyfile[f] = schema

        self.logger.debug("Read %s schema definitions from %s." %
                          (len(self._schemas), filename))

