import zope.component

import CipraSync.resolve
import CipraSync.transform
import CipraSync.read
import CipraSync.write
import CipraSync.writehandler

# resolvers
def resolver():
    zope.component.provideUtility(
        CipraSync.resolve.CipraResolver(),
        name='cipra-resolver',
        )

# transforms
def transforms():
    zope.component.provideUtility(
        CipraSync.transform.DateTransform(),
        name='cipra-transform-date',
        )

    zope.component.provideUtility(
        CipraSync.transform.TextTransform(),
        name='cipra-transform-text',
        )
    
    # instantiate  file transforms here, because importing
    # transform should not need to read reader.ini
    pdfTransform = CipraSync.transform.FileTransform(key='Directories.pdf')
    imageTransform = CipraSync.transform.FileTransform(key='Directories.image')
    zope.component.provideUtility(
        pdfTransform,
        name='cipra-transform-pdffile',
        )       
    zope.component.provideUtility(
        imageTransform,
        name='cipra-transform-imagefile',
        ) 
        
    zope.component.provideUtility(
        CipraSync.transform.IdTransform(),
        name='cipra-transform-id',
        )
        
    zope.component.provideUtility(
        CipraSync.transform.LanguageTransform(),
        name='cipra-transform-language',
        )

    zope.component.provideUtility(
        CipraSync.transform.domainReferenceTransform,
        name='cipra-transform-domainreference',
        )

    zope.component.provideUtility(
        CipraSync.transform.newsAddressAuthorReferenceTransform,
        name='cipra-transform-news-address-author-reference',
        )

    zope.component.provideUtility(
        CipraSync.transform.pdfAddressAuthorReferenceTransform,
        name='cipra-transform-pdf-address-author-reference',
        )
        
    zope.component.provideUtility(
        CipraSync.transform.imageAddressAuthorReferenceTransform,
        name='cipra-transform-image-address-author-reference',
        )

    zope.component.provideUtility(
        CipraSync.transform.imageAddressObtainedFromReferenceTransform,
        name='cipra-transform-image-address-obtained-reference',
        )

    zope.component.provideUtility(
        CipraSync.transform.imageAddressCopyrightReferenceTransform,
        name='cipra-transform-image-address-copyright-reference',
        )

    zope.component.provideUtility(
        CipraSync.transform.relatedItemsMetaReferenceTransform,
        name='cipra-transform-related-items-reference',
        )
        

    zope.component.provideUtility(
        CipraSync.transform.TypeTransform(),
        name='cipra-transform-type',
        )

    zope.component.provideUtility(
        CipraSync.transform.DomainTreeVocabularyTransform(),
        name='cipra-transform-domaintreevocabulary',
        )

    zope.component.provideUtility(
        CipraSync.transform.TreeVocabularyTermTransform(),
        name='cipra-transform-treevocabularyterm',
        )

    zope.component.provideUtility(
        CipraSync.transform.AddressTypeTransform(),
        name='cipra-transform-addresstype',
        )
        
    zope.component.provideUtility(
        CipraSync.transform.TreeVocabularyPathTransform(),
        name='cipra-transform-treevocabulary-path',
        )        

    zope.component.provideUtility(
        CipraSync.transform.regionReferenceTransform,
        name='cipra-transform-regionreference',
        )
        
    zope.component.provideUtility(
        CipraSync.transform.LanguageIndependentTransform(),
        name='cipra-marker-language_independent',
        )        

# reader and writer
def reader():
    zope.component.provideUtility(CipraSync.read.Reader())
    
def writer():
    zope.component.provideAdapter(CipraSync.write.Writer)

def writehandlers():
    zope.component.provideAdapter(CipraSync.writehandler.BasicHandler,
                                  name='cipra-basichandler')
    zope.component.provideAdapter(CipraSync.writehandler.ReferenceHandler,
                                  name='cipra-referencehandler')
    zope.component.provideAdapter(CipraSync.writehandler.LinguaploneHandler,
                                  name='cipra-lp_handler')
    zope.component.provideAdapter(CipraSync.writehandler.TreeVocabLinguaploneHandler,
                                  name='cipra-treevocab_lp_handler')

def all():
    resolver()
    transforms()
    reader()
    writer()
    writehandlers()
    
